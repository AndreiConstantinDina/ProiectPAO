import java.io.*;
import java.util.*;


public class Main{


    public static void main(String[] args){



        Repository repository = new Repository();
        Service service = new Service(repository);
        Scanner sc = new Scanner(System.in);


        repository.citireFisier();

        while(true){
            int instruction =0;
            try{
                System.out.println("Alegeti una dintre urmatoarele optiuni:\n"
                    +"1. Adauga film\n"
                    +"2. Sterge film\n"
                    + "3. Afisaza filmele existente\n"
                    + "4. Modifica film\n"
                    + "5. Cautare film\n"
                    + "6. Sortare filme\n"
                    + "0. Exit and save\n"

            );
                instruction = sc.nextInt();

                switch (instruction){
                    case(0):{
                        System.out.println("Exiting...");
                        try{
                            repository.scriereFisier();
                        }
                        catch (IOException io){
                            return;
                        }
                        return;
                    }
                    case (1):{
                        System.out.println("Introduceti anul: ");
                        int an = sc.nextInt();
                        sc.nextLine();
                        System.out.println("\nIntroduceti genul: ");
                        String gen = sc.nextLine();
                        System.out.println("\nItroduceti actorul: ");
                        String actor = sc.nextLine();
                        System.out.println("\nIntroduceti titlul: ");
                        String titlu = sc.nextLine();
                        Film f = new Film (titlu, gen, actor, an);
                        try{
                            service.adauga_film(f);
                        }

                        catch (RepoError err){
                            System.out.println(err);
                        }

                        catch (ValidationError err){
                            System.out.println(err);
                        }
                        break;
                    }

                    case (2):{
                        System.out.println("Introduceti anul filmului pe care doriti sa il stergeti: ");
                        int an = sc.nextInt();
                        sc.nextLine();
                        System.out.println("\nIntroduceti genul pe care doriti sa il stergeti: ");
                        String gen = sc.nextLine();
                        System.out.println("\nItroduceti actorul pe care doriti sa il stergeti: ");
                        String actor = sc.nextLine();
                        System.out.println("\nIntroduceti titlul pe care doriti sa il stergeti: ");
                        String titlu = sc.nextLine();
                        Film f = new Film (titlu, gen, actor, an);
                        try{
                            service.sterge_film(f);
                        }

                        catch (RepoError err){
                            System.out.println(err);
                        }

                        catch (ValidationError err){
                            System.out.println(err);
                        }
                        break;
                    }

                    case(3):{
                        var filme = service.getFilme();
                        for (var f:filme)
                            System.out.println(f);
                        break;
                    }

                    case(4):{
                        System.out.println("Introduceti anul filmului pe care doriti sa il modificati: ");
                        int an = sc.nextInt();
                        sc.nextLine();
                        System.out.println("\nIntroduceti genul filmului pe care doriti sa il modificati: ");
                        String gen = sc.nextLine();
                        System.out.println("\nItroduceti actorul filmului pe care doriti sa il modificati: ");
                        String actor = sc.nextLine();
                        System.out.println("\nIntroduceti titlul filmului pe care doriti sa il modificati: ");
                        String titlu = sc.nextLine();
                        Film f = new Film (titlu, gen, actor, an);

                        System.out.println("Introduceti anul nou: ");
                        int an2 = sc.nextInt();
                        sc.nextLine();
                        System.out.println("\nIntroduceti genul nou: ");
                        String gen2 = sc.nextLine();
                        System.out.println("\nItroduceti actorul nou: ");
                        String actor2 = sc.nextLine();
                        System.out.println("\nIntroduceti titlul nou: ");
                        String titlu2 = sc.nextLine();
                        Film f2 = new Film (titlu2, gen2, actor2, an2);

                        try{
                            service.modifica_film(f,f2);
                        }

                        catch (RepoError err){
                            System.out.println(err);
                        }

                        catch (ValidationError err){
                            System.out.println(err);
                        }
                        break;

                    }

                    case(5):{
                        System.out.println("Alegeti una dintre urmatoarele optiuni pentru cautare:\n"
                                +"1. Cautare dupa an\n"
                                +"2. Cautare dupa gen\n"
                                + "3. Cautare dupa titlu\n"
                                + "4. Cautare dupa actor\n");

                        int instruction2 = sc.nextInt();
                        sc.nextLine();
                        switch(instruction2){
                            case(1):{
                                try{
                                System.out.println("Introduceti anul: \n");
                                int anCautare = sc.nextInt();
                                var filme = service.cautare_an(anCautare);
                                for (var f:filme)
                                    System.out.println(f);
                                }
                                catch (InputMismatchException e){
                                    System.out.println("Valoare invalida.\n");
                                }
                                break;
                            }
                            case(2):{
                                System.out.println("Introduceti genul: \n");
                                String genCautare = sc.nextLine();
                                var filme = service.cautare_gen(genCautare);
                                for (var f:filme)
                                    System.out.println(f);
                                break;
                            }
                            case(3):{
                                System.out.println("Introduceti titlul: \n");
                                String titluCautare = sc.nextLine();
                                var filme = service.cautare_titlu(titluCautare);
                                for (var f:filme)
                                    System.out.println(f);
                                break;
                            }

                            case(4):{
                                System.out.println("Introduceti actorul: \n");
                                String actorCautare = sc.nextLine();
                                var filme = service.cautare_actor(actorCautare);
                                for (var f:filme)
                                    System.out.println(f);
                                break;
                            }

                            default:{
                                System.out.println("Instructiune invalida.\n");
                            }

                        }
                    }

                    case(6):{
                        System.out.println("Alegeti una dintre urmatoarele optiuni pentru sortare:\n"
                                +"1. Sortare dupa an\n"
                                +"2. Sortare dupa gen\n"
                                + "3. Sortare dupa titlu\n"
                                + "4. Sortare dupa actor\n");
                        int instruction3 = sc.nextInt();
                        switch(instruction3) {
                            case (1): {
                                var filme = service.getFilme();

                                Collections.sort(filme, new Comparator<Film>() {
                                    @Override
                                    public int compare(Film o1, Film o2) {
                                        return o1.getAn() - o2.getAn();
                                    }
                                });
                                for (var f : filme)
                                    System.out.println(f);

                                break;
                            }

                            case (2): {
                                var filme = service.getFilme();

                                Collections.sort(filme, new Comparator<Film>() {
                                    @Override
                                    public int compare(Film o1, Film o2) {
                                        return o1.getGen().compareTo(o2.getGen());
                                    }
                                });
                                for (var f : filme)
                                    System.out.println(f);

                                break;
                            }

                            case (3): {
                                var filme = service.getFilme();

                                Collections.sort(filme, new Comparator<Film>() {
                                    @Override
                                    public int compare(Film o1, Film o2) {
                                        return o1.getTitlu().compareTo(o2.getTitlu());
                                    }
                                });
                                for (var f : filme)
                                    System.out.println(f);

                                break;
                            }

                            case (4): {
                                var filme = service.getFilme();

                                Collections.sort(filme, new Comparator<Film>() {
                                    @Override
                                    public int compare(Film o1, Film o2) {
                                        return o1.getActor().compareTo(o2.getActor());
                                    }
                                });
                                for (var f : filme)
                                    System.out.println(f);

                                break;

                            }

                        }
                    }


                    default:
                        System.out.println("Instructiune invalida. Introduceti un numar de ordine valid. \n");
                }

            }
            catch (InputMismatchException e){
                System.out.println("Valoare invalida.\n");
                sc.nextLine();
            }

        }

    }
}
