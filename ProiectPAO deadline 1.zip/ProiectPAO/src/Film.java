public class Film {
    String titlu;
    String gen;
    String actor;
    int an;

    public Film(String titlu, String gen, String actor, int an) {
        this.titlu = titlu;
        this.gen = gen;
        this.actor = actor;
        this.an = an;
    }

    public String getTitlu() {
        return titlu;
    }

    public void setTitlu(String titlu) {
        this.titlu = titlu;
    }

    public String getGen() {
        return gen;
    }

    public void setGen(String gen) {
        this.gen = gen;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public int getAn() {
        return an;
    }

    public void setAn(int an) {
        this.an = an;
    }

    public boolean equals(Film other){
        boolean result = false;
        if (other.an == this.an && other.actor.equals(this.actor) && other.titlu.equals(this.titlu) && other.gen.equals(this.gen))
            result = true;
        return result;
    }

    @Override
    public String toString() {
        return "Film{" +
                "titlu='" + titlu + '\'' +
                ", gen='" + gen + '\'' +
                ", actor='" + actor + '\'' +
                ", an=" + an +
                "}\n";
    }
}
