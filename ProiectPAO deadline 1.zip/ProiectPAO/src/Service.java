import java.util.ArrayList;
import java.util.List;

public class Service {
    Repository repository;

    public Service(Repository repository) {
        this.repository = repository;
    }

    List<Film> getFilme(){
        return repository.getFilme();

    }

    void adauga_film(Film f) throws ValidationError, RepoError{
        Validator validator = new Validator();
        validator.valideaza(f);
        this.repository.adauga_film(f);

        return;
    }
    void sterge_film(Film f) throws ValidationError, RepoError{
        Validator validator = new Validator();
        validator.valideaza(f);
        this.repository.sterge_film(f);

        return;
    }


    void modifica_film(Film f, Film f2) throws ValidationError, RepoError{
        Validator validator = new Validator();
        validator.valideaza(f);
        validator.valideaza(f2);
        this.repository.sterge_film(f);
        this.repository.adauga_film(f2);

    }

    List <Film> cautare_an(int an){
        var filme = repository.getFilme();
        var result = new ArrayList<Film>();
        for (Film f:filme)
            if (f.getAn() == an)
                result.add(f);
        return result;
    }

    List <Film> cautare_gen(String gen){
        var filme = repository.getFilme();
        var result = new ArrayList<Film>();
        for (Film f:filme)
            if (f.getGen().matches(gen))
                result.add(f);
        return result;
    }

    List <Film> cautare_titlu(String titlu){
        var filme = repository.getFilme();
        var result = new ArrayList<Film>();
        for (Film f:filme)
            if (f.getTitlu().matches(titlu))
                result.add(f);
        return result;
    }

    List <Film> cautare_actor(String actor){
        var filme = repository.getFilme();
        var result = new ArrayList<Film>();
        for (Film f:filme)
            if (f.getActor().matches(actor))
                result.add(f);
        return result;
    }

}
