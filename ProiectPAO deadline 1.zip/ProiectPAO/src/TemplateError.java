public class TemplateError {
    String message;

    public TemplateError(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
