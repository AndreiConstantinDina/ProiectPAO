import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import static java.lang.Integer.parseInt;
import static java.lang.String.valueOf;

public class Repository {

     List<Film> filme;

     List <Film> getFilme(){
         return this.filme;
     }

    public Repository() {
        this.filme = new ArrayList<Film>();
    }

    public void adauga_film(Film f)  throws RepoError{
        for (var el:this.filme)
            if (el.equals(f)){
                throw new RepoError("Film deja existent.\n");
            }
        this.filme.add(f);
     }

    public void sterge_film(Film f) throws RepoError{
        List <Film> toRemove = new ArrayList();
        for (Film film : this.filme) {
            if(film.equals(f)) {
                toRemove.add(film);
            }
        }
        if (toRemove.size() != 0)
            this.filme.removeAll(toRemove);
        else throw new RepoError("Film inexistent. \n");
        }

    public void scriereFisier() throws IOException {

        FileWriter fw = new FileWriter("repository.txt", true);
        BufferedWriter bw = new BufferedWriter(fw);

        for (Film f: this.filme){
            String an = String.valueOf(f.getAn());
            bw.write( an+ ", "+ f.getGen()+ ", "+ f.getActor()+ ", " + f.getTitlu()+ "\n");
        }
        bw.close();
        }

        public void citireFisier() {
            try {
                File myObj = new File("repository.txt");
                Scanner myReader = new Scanner(myObj);
                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    String [] dataArray = data.split(", ");
                    Film f = new Film(dataArray[3], dataArray[1], dataArray[2], parseInt(dataArray[0]));
                    this.filme.add(f);
                }
                myReader.close();
                new FileWriter("repository.txt", false).close();
            } catch (FileNotFoundException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
}
