import java.lang.Exception;

public class RepoError extends Exception{
    public RepoError(String message) {
        super(message);
    }
}
