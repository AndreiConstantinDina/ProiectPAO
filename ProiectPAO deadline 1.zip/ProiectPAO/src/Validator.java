public class Validator {

    void valideaza(Film f) throws ValidationError{
        String erori="";

        if (f.getAn() < 1800 || f.getAn() > 2022)
            erori = erori.concat("An invalid.\n");
        var actor = f.getActor();
        for (var ch:actor.toCharArray())
            if (ch != ' ' && (ch<'a' || ch>'z') && (ch<'A' || ch>'Z'))
                erori = erori.concat("Numele actorului este invalid. Acesta poate sa contina doar litere si spatii.\n");
        var gen = f.getGen();
        if ((!gen.equals("drama")) && (!gen.equals("comedie")) && (!gen.equals("actiune")) && (!gen.equals("horror")) && (!gen.equals("dragoste")) &&
                (!gen.equals("documentar")) && (!gen.equals("thriller")))
            erori = erori.concat("Gen invalid\n");

        if (!erori.equals(""))
            throw new ValidationError(erori);
    }
}
